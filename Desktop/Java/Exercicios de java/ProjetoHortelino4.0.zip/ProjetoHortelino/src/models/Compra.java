package models;

import java.util.Vector;

public class Compra {
	
	private int num;
	private String data;
	private String hora;
	private Produto produto;
	private int quantidade;
	
	//GETs && SETss
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getHora() {
		return hora;
	}
	public void setHora(String hora) {
		this.hora = hora;
	}
	public Produto getProduto() {
		return produto;
	}
	public void setProduto(Produto produto) {
		this.produto = produto;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	
	//Outros M�todos
	public double getSubtotal() {
		return this.quantidade * this.produto.getPreco();
	}
	
	@Override
	public String toString() {
		return "Compra [num=" + num + ", data=" + data + ", hora=" + hora + ", produto=" + produto.getCodigo() + ", preco =" + produto.getPreco() + ", quantidade="
				+ quantidade + "]";
	}
	
	public String toCSV() {
		return num + ";" + data + ";" + hora + ";" + produto.getCodigo() + ";" + produto.getPreco() + ";" + quantidade + "\r\n";
	}
	
	public String cabecalho() {
		return "Numero   Data               Hora                   (Cod Produto                          Pre�o)      Quantidade";
	}
	
	public String[] getStringVetor() {
		return new String[] { "" + num, data, hora, "" + produto.getCodigo(), "" + produto.getPreco(), "" + quantidade,
				"" + getSubtotal() };
	}

}
